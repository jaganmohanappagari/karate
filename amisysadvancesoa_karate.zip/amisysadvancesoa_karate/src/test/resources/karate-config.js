function fn() {
    var env = karate.env;
    var port = 30388;
    var baseUrl = 'http://dsthp70';

    if (env == 'test') {
        port = 30388;
        karate.log(baseUrl);
    }

    var config = {
        env: env,
        memberFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/memberFlatService?wsdl',
        authorizationSearchFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/authorizationSearchFlatService?wsdl',
        authorizationFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/authorizationFlatService?wsdl',
        claimFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/claimFlatSearchService?wsdl',
        codeSetFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/codeSetFlatService?wsdl',
        groupSearchFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/groupSearchFlatService?wsdl',
        healthPlanFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/healthPlanFlatService?wsdl',
        providerAffiliationFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/providerAffiliationFlatSearchService?wsdl',
        providerSearchFlatServiceUrl: baseUrl + ':' + port + '/amisys-soa/soap/clientd/providerSearchFlatService?wsdl',
        arkansasUrl:'http://dhkcopsrlstst01:8084/soap?client=aa-89-lx-auto-qa',
        //http://dhkcopsrlstst01:8084/soap?client=aa-89-lx-auto-qa

        //87AutoQA Linux: http://dhbhtiwebdevah:8084/soap?client=aa-87-lx
        //86AutoQA Linux: http://dhbhtiwebdevah:8084/soap?client=aa-86-lx-auto
        //85AutoQA Linux
        //arkansasUrl:'http://dhbhtiwebdevah:8084/soap/aa-86-lx-auto',
        //84Autoqa Linux
        //arkansasUrl:http://dhbhtiwebdevah:8084/soap?client=aa-84-lx-auto
        //qa url tested is below one
        //arkansasUrl:'http://dhbhtiwebdevah:8084/soap?client=aa-84-qa',
        test:'http://dhbhtiwebdevah:8084/soap?client=aa-84-qa'
    };

    karate.configure('connectTimeout', 30000);
    karate.configure('readTimeout', 60000);
    return config;
}