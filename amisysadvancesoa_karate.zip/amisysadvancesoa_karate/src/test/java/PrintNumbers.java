public class PrintNumbers {
    public static void printNos(int i){

        if( i  <= 0){
            return;
        }else{
             printNos(i-1);
            System.out.println(i);
        }

    }
    public static void main(String args[]){
        printNos(10);
    }
}
